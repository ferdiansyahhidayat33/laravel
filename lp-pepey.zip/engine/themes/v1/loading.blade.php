@php
    $url_offer = config('tmdb.url_offer_default');
    $title = '';
    $id = '';
    if ( isset($_REQUEST['sub_id']) ) {
        $url_offer = config('tmdb.url_offer_sub_id').$_REQUEST['sub_id'];
    }
    if ( isset($_REQUEST['title']) ) {
        $title = $_REQUEST['title'];
    }
    if ( isset($_REQUEST['title']) ) {
        $id = $_REQUEST['id'];
    }
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="noindex">
    <title>{{ $id }} {{ $title }} Loading...</title>
    <meta http-equiv="refresh" content="0;url={{ $url_offer }}">

    <style>
        .loading-redirect {
            height: 100vh;
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
        }
        .text-center {
            text-align: center!important;
        }
        .lds-dual-ring {
            display: inline-block;
            width: 64px;
            height: 64px;
        }
        .lds-dual-ring:after {
            content: " ";
            display: block;
            width: 46px;
            height: 46px;
            margin: 1px;
            border-radius: 50%;
            border: 5px solid #222;
            border-color: #222 transparent #222 transparent;
            animation: lds-dual-ring 1.2s linear infinite;
        }
        @keyframes lds-dual-ring {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    </style>
    @include('header')
</head>
<body class="text-center loading-redirect">
    <div class="lds-dual-ring"></div>
    @include('footer')
</body>
</html>
