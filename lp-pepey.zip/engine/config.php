<?php

return [
    'api_key' => '892b7c8469f251441be840cf2aeb9d74',
    'tmdb_debug' => false,
    'theme' => 'v1',
    'is_cache' => true,
    'cache_exp' => 1440,

    'url_offer_default' => 'https://affcpatrk.com/link?id=6495531bdb8574ae654fd9b0&aff_sub=pepey',
    'url_offer_sub_id' => 'https://affcpatrk.com/link?id=6495531bdb8574ae654fd9b0&aff_sub=pepey',
	
	'export_button_watch' => 'https://affcpatrk.com/link?id=6495531bdb8574ae654fd9b0&aff_sub=pepey',
	'export_button_download' => 'https://affcpatrk.com/link?id=6495531bdb8574ae654fd9b0&aff_sub=pepey',

    'block_movie' => [],
    'block_tv' => [],

    'max_limit_page_sitemap' => 5,
];
