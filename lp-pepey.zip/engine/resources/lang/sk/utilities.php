<?php

return [
    'view_all'        => 'Zobraziť všetko',
    'subscribe_watch' => 'Prihláste sa na odber služby Watch | $0.00',
    'released'        => 'Vydané',
    'runtime'         => 'Runtime',
    'genre'           => 'Žáner',
    'stars'           => 'Hviezdy',
    'director'        => 'Réžia',
    'minutes'         => 'minút',
    'by'              => 'od',
    'users'           => 'používateľov',
    'download'        => 'Stiahnuť ▼',
    'season'          => 'Sezóna',
    'watch'           => 'Sledovať teraz',
    'episode'         => 'Epizóda',
    'movies'          => 'Filmy',
    'know_for'        => 'Známy pre',
    'birthday'        => 'Výročie narodenia',
    'place_of_birth'  => 'Miesto narodenia',
    'also_know_as'    => 'Tiež známy ako',
    'biography'       => 'životopis',
    'sign_in'         => 'Prihlásiť sa',
    'register'        => 'Registrovať',

    'watch_now'       => 'Sledovať teraz',
];
