<?php

return [
    'previous' => '&laquo; předchozí',
    'next'     => 'další &raquo;',
];
