<?php

return [
    'home_title'       => 'Strumieniowe filmy i programy telewizyjne',
    'home_description' => 'Przeglądaj i oglądaj wszystkie swoje ulubione filmy i seriale online za darmo!',

    'movie_title' => 'Oglądaj :title Full Movie Online za darmo',
    'tv_title'    => 'Oglądaj :title HD Free TV Show',
];
