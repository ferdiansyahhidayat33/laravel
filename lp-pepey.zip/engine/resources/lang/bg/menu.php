<?php

return [
    'movies'         => 'Филми',
    'popular'        => 'Популярни',
    'now_playing'    => 'Излъчвани в момента',
    'top_rated'      => 'Най-високо',
    'upcoming'       => 'оценени',
    'tv_shows'       => 'Сериали',
    'on_tv'          => 'По телевизията',
    'airing_today'   => 'Излъчвани днес',
    'genres'         => 'Жанрове',
    'popular_people' => 'Популярни хора',
    'search'         => 'Търсене...',
];
