<?php

return [
    'movies'         => 'Movies',
    'popular'        => 'Popular',
    'now_playing'    => 'Now Playing',
    'top_rated'      => 'Top Rated',
    'upcoming'       => 'Upcoming',
    'tv_shows'       => 'TV Shows',
    'on_tv'          => 'On TV',
    'airing_today'   => 'Airing Today',
    'genres'         => 'Genres',
    'popular_people' => 'Popular People',
    'search'         => 'Search...',
];
