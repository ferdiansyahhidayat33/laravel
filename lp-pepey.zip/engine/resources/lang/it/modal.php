<?php

return [
    'active_your_account_free' => 'Attiva il tuo account GRATUITO !',
    'you_must_create' => 'È necessario creare un account per continuare a guardare',
    'continue_watch' => 'Continua a guardare GRATIS ➞',
    'quick_sign_up' => 'Registrazione rapida!',
    'take_less_then' => 'Ci vuole meno di 1 minuto per registrarsi, quindi puoi goderti i film e i titoli TV illimitati.',
];
