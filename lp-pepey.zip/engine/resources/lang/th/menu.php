<?php

return [
    'movies'         => 'ภาพยนตร์',
    'popular'        => 'เป็นที่นิยมใน',
    'now_playing'    => 'ขณะนี้กำลังเล่น',
    'top_rated'      => 'ยอดนิยมที่',
    'upcoming'       => 'จะเกิดขึ้น',
    'tv_shows'       => 'รายการโทรทัศน์',
    'on_tv'          => 'มีทีวี',
    'airing_today'   => 'กำลังออกอากาศวันนี้',
    'genres'         => 'ประเภท',
    'popular_people' => 'คนนิยม',
    'search'         => 'ค้นหา...',
];

