<?php

return [
    'view_all'        => 'ดูทั้งหมด',
    'subscribe_watch' => 'สมัครสมาชิกเพื่อรับชม | $0.00',
    'released'        => 'เปิดตัว',
    'runtime'         => 'เวลา',
    'genre'           => 'ประเภท',
    'stars'           => 'ดาว',
    'director'        => 'ผู้กำกับ',
    'minutes'         => 'นาที',
    'by'              => 'โดยผู้ใช้',
    'users'           => 'คน',
    'download'        => 'ดาวน์โหลด',
    'season'          => 'ฤดู',
    'watch'           => 'ดู',
    'episode'         => 'ตอนที่',
    'movies'          => 'ภาพยนตร์',
    'know_for'        => 'เป็นที่รู้จักสำหรับ',
    'birthday'        => 'วันเกิด',
    'place_of_birth'  => 'สถานที่เกิด',
    'also_know_as'    => 'หรือเป็นที่รู้จักอีกอย่างว่า',
    'biography'       => 'ชีวประวัติ',
    'sign_in'         => 'ลงชื่อเข้าใช้',
    'register'        => 'สมัครสมาชิก',

    'watch_now'       => 'ดูตอนนี้',
];
