<?php

return [
    'active_your_account_free' => 'Activează-ți contul GRATUIT!',
    'you_must_create'          => 'Trebuie să creați un cont pentru a continua vizionarea',
    'continue_watch'           => 'Continuați să urmăriți GRATUIT ➞',
    'quick_sign_up'            => 'Înregistrare rapidă!',
    'take_less_then'           => 'Este nevoie de mai puțin de 1 minut pentru a vă înscrie, apoi vă puteți bucura de filme nelimitate și titluri TV.',
];
