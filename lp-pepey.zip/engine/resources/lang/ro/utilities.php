<?php

return [
    'view_all'        => 'A Vedea Tot',
    'subscribe_watch' => 'Abonează-te la Urmărire | $0.00',
    'released'        => 'Publicat',
    'runtime'         => 'Durata de functionare',
    'genre'           => 'Gen',
    'stars'           => 'Stele',
    'director'        => 'Regizor',
    'minutes'         => 'minute',
    'by'              => 'de',
    'users'           => 'utilizatori',
    'download'        => 'Descărcare',
    'season'          => 'Season',
    'watch'           => 'Watch',
    'episode'         => 'Episode',
    'movies'          => 'Movies',
    'know_for'        => 'Cunoscut pentru',
    'birthday'        => 'Zi de nastere',
    'place_of_birth'  => 'Locul nașterii',
    'also_know_as'    => 'Cunoscut și ca',
    'biography'       => 'Biografie',
    'sign_in'         => 'Conectare',
    'register'        => 'Inregistreaza-te',

    'watch_now'       => 'Priveste Acum',
];
