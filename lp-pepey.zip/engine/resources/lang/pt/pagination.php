<?php

return [
    'previous' => '&laquo; Anterior',
    'next'     => 'Próxima &raquo;',
];
