<?php

return [
    'active_your_account_free' => 'Activez votre compte GRATUIT !',
    'you_must_create' => 'Vous devez créer un compte pour continuer à regarder',
    'continue_watch' => 'Continuer à regarder gratuitement ➞',
    'quick_sign_up' => 'Inscription rapide!',
    'take_less_then' => 'Cela prend moins de 1 minute pour vous inscrire, vous pourrez alors profiter de titres illimités de films et de séries télévisées.',
];
