<?php

return [
    'previous' => '&lsaquo; Préc',
    'next' => 'Suivante &rsaquo;'
];
