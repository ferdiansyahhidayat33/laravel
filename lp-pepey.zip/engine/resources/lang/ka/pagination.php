<?php

return [
    'previous' => '&laquo; წინა',
    'next'     => 'შემდეგი &raquo;',
];
