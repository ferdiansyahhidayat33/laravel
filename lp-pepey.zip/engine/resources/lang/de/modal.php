<?php

return [
    'active_your_account_free' => 'Aktivieren Sie Ihr KOSTENLOSES Konto!',
    'you_must_create'          => 'Sie müssen ein Konto erstellen, um die Wiedergabe fortzusetzen',
    'continue_watch'           => 'Schau weiter KOSTENLOS zu ➞',
    'quick_sign_up'            => 'Schnell anmelden!',
    'take_less_then'           => 'Es dauert weniger als 1 Minute, um sich anzumelden, dann können Sie Unlimited Movies & TV-Titel genießen.',
];
