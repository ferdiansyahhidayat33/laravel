<?php

return [
    'home_title'       => 'Kostenlose Filme und Fernsehsendungen streamen',
    'home_description' => 'Stöbern Sie und schauen Sie sich alle Ihre Lieblings-Online-Filme und Serien kostenlos an!',

    'movie_title' => 'Voller Film in :title online anschauen Kostenlos',
    'tv_title'    => 'Sehen Sie :title HD Free TV Show',
];
