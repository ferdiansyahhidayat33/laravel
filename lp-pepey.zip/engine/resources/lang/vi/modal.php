<?php

return [
    'active_your_account_free' => 'Kích hoạt tài khoản MIỄN PHÍ của bạn!',
    'you_must_create'          => 'Bạn phải tạo một tài khoản để tiếp tục xem',
    'continue_watch'           => 'Tiếp tục xem MIỄN PHÍ ➞',
    'quick_sign_up'            => 'Đăng ký nhanh!',
    'take_less_then'           => 'Chỉ mất chưa đến 1 phút để Đăng ký, sau đó bạn có thể thưởng thức các tựa phim và TV không giới hạn.',
];
