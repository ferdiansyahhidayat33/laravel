<?php

return [
    'sign_in'             => 'Đăng nhập',
    'email'               => 'E-mail',
    'password'            => 'Mật khẩu',
    'well_never_share'    => 'Chúng tôi sẽ không bao giờ chia sẻ email của bạn với bất cứ ai khác.',
    'forgot_password'     => 'Quên mật khẩu?',
    'or'                  => 'Hoặc là',
    'create_free_account' => 'Tạo Tài Khoản Miễn Phí',

    'enter_email'      => 'Nhập email',
    'reset_password'   => 'Đặt Lại Mật Khẩu',
    'enter_your_email' => 'Nhập địa chỉ email của bạn và chúng tôi sẽ gửi cho bạn một liên kết để đặt lại mật khẩu của bạn.',
    'back_to_sign_in'  => 'Quay lại Đăng nhập',
    'loading'          => 'Đợi đã...',
];
