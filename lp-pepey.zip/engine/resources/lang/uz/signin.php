<?php

return [
    'sign_in'             => 'Tizimga kirish',
    'email'               => 'Elektron pochta',
    'password'            => 'Parol',
    'well_never_share'    => 'Biz hech qachon elektron pochta xabarlaringizni hech kim bilan baham ko\'rmaymiz.',
    'forgot_password'     => 'Parolni unutdingizmi?',
    'or'                  => 'Yoki',
    'create_free_account' => 'Bepul hisob yarating',

    'enter_email'      => 'E-pochtani kiriting',
    'reset_password'   => 'Parolni Tiklash',
    'enter_your_email' => 'Elektron pochta manzilingizni kiriting va parolingizni tiklash uchun sizga havolani yuboramiz.',
    'back_to_sign_in'  => 'Tizimga qaytish',
    'loading'          => 'Kutmoq...',
];
