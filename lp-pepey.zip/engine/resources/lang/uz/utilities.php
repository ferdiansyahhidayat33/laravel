<?php

return [
    'view_all'        => 'Hammasini Ko\'rish',
    'subscribe_watch' => 'Ko\'rishga Obuna Bo\'ling | $0.00',
    'released'        => 'Chiqarilgan vaqti',
    'runtime'         => 'Ish vaqti',
    'genre'           => 'Janr',
    'stars'           => 'Yulduzlar',
    'director'        => 'Rejissyor',
    'minutes'         => 'daqiqa',
    'by'              => 'Tomonidan',
    'users'           => 'Foydalanuvchilar',
    'download'        => 'Yuklash',
    'season'          => 'Fasl',
    'watch'           => 'Ko\rilmoqda',
    'episode'         => 'Qism',
    'movies'          => 'Filmlar',
    'know_for'        => 'Ma\'lum',
    'birthday'        => 'Tug\'ilgan yili',
    'place_of_birth'  => 'Tug\'ilgan joyi',
    'also_know_as'    => 'Shuningdek, taniqli',
    'biography'       => 'Tarjimai hol',
    'sign_in'         => 'Tizimga Kirish',
    'register'        => 'Ro\'yxatdan o\'ting',

    'watch_now'       => 'Hozir Tomosha Qiling',
];
