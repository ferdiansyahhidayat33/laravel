<?php

return [
    'previous' => '&laquo; 上一页',
    'next'     => '下一页 &raquo;',
];
