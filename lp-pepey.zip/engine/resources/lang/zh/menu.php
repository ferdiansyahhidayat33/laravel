<?php

return [
    'movies'         => '电影',
    'popular'        => '热门',
    'now_playing'    => '正在上映',
    'top_rated'      => '高分',
    'upcoming'       => '即将上映',
    'tv_shows'       => '剧集',
    'on_tv'          => '在电视上',
    'airing_today'   => '今日播出',
    'genres'         => '类型',
    'popular_people' => '人物',
    'search'         => '搜索...',
];



