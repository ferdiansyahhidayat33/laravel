<?php

return [
    'active_your_account_free' => '激活您的免费帐户！',
    'you_must_create'          => '您必须创建一个帐户才能继续观看',
    'continue_watch'           => '继续免费观看 ➞',
    'quick_sign_up'            => '快速注册！',
    'take_less_then'           => '注册只需不到1分钟，您就可以享受无限电影和电视节目。',
];
