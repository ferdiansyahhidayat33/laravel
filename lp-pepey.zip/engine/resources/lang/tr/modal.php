<?php

return [
    'active_your_account_free' => 'ÜCRETSİZ Hesabınızı etkinleştirin!',
    'you_must_create'          => 'İzlemeye devam etmek için bir hesap oluşturmanız gerekir',
    'continue_watch'           => 'ÜCRETSİZ izlemeye devam edin ➞',
    'quick_sign_up'            => 'Hızlı Kayıt!',
    'take_less_then'           => 'Kayıt olmak 1 dakikadan az sürüyor, ardından Sınırsız Film ve TV başlıklarının keyfini çıkarabilirsiniz.',
];
