<?php

return [
    'sign_in'             => 'Oturum aç',
    'email'               => 'E-posta',
    'password'            => 'Parola',
    'well_never_share'    => 'E-postalarınızı asla başkasıyla paylaşmayacağız.',
    'forgot_password'     => 'Parolanızı mı unuttunuz?',
    'or'                  => 'Veya',
    'create_free_account' => 'Ücretsiz hesap oluştur',

    'enter_email'      => 'E-posta Girin',
    'reset_password'   => 'Şifreyi yenile',
    'enter_your_email' => 'E-posta adresinizi girin, şifrenizi sıfırlamanız için size bir link gönderelim.',
    'back_to_sign_in'  => 'Oturum Açmaya Geri Dön',
    'loading'          => 'Bekleyin...',
];
