<?php

return [
    'home_title'       => 'Patak ingyenes filmek és TV-műsorok',
    'home_description' => 'Keresse meg és nézze meg kedvenc online filmjét és sorozatát ingyen!',

    'movie_title' => 'Nézze meg a :title teljes filmet online ingyen',
    'tv_title'    => 'Nézze meg a :title HD ingyenes TV-műsorokat',
];
