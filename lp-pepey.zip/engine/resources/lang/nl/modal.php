<?php

return [
    'active_your_account_free' => 'Activeer uw GRATIS account!',
    'you_must_create'          => 'U moet een account maken om verder te kunnen kijken',
    'continue_watch'           => 'Blijf GRATIS kijken ➞',
    'quick_sign_up'            => 'Snel aanmelden!',
    'take_less_then'           => 'Het duurt minder dan 1 minuut om u aan te melden, waarna u kunt genieten van onbeperkte films en tv-titels.',
];
