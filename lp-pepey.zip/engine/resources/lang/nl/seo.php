<?php

return [
    'home_title'       => 'Stream gratis films en tv-programma\'s',
    'home_description' => 'Blader en bekijk al uw favoriete online films en series gratis!',

    'movie_title' => 'Bekijk :title Volledige film online gratis',
    'tv_title'    => 'Bekijk :title HD gratis tv-programma\'s',
];
