<?php

return [
    'movies'         => 'Films',
    'popular'        => 'Populair',
    'now_playing'    => 'Nu in de bioscoop',
    'top_rated'      => 'Best beoordeeld',
    'upcoming'       => 'Binnenkort',
    'tv_shows'       => 'TV-series',
    'on_tv'          => 'Op TV',
    'airing_today'   => 'Vandaag op TV',
    'genres'         => 'Genres',
    'popular_people' => 'Populaire personen',
    'search'         => 'Zoeken...',
];


