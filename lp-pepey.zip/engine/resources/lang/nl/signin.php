<?php

return [
    'sign_in'             => 'Aanmelden',
    'email'               => 'E-mail',
    'password'            => 'Wachtwoord',
    'well_never_share'    => 'We zullen uw e-mail nooit met iemand anders delen.',
    'forgot_password'     => 'Wachtwoord vergeten?',
    'or'                  => 'Of',
    'create_free_account' => 'Maak een gratis account aan',

    'enter_email'      => 'Voer email in',
    'reset_password'   => 'Reset wachtwoord',
    'enter_your_email' => 'Voer je e-mailadres in en we sturen je een link om je wachtwoord opnieuw in te stellen.',
    'back_to_sign_in'  => 'Terug naar inloggen',
    'loading'          => 'Wacht even...',
];
