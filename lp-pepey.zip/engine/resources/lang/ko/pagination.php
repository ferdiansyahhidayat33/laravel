<?php

return [
    'previous' => '&lsaquo; 이전',
    'next'     => '다음 &rsaquo;'
];
