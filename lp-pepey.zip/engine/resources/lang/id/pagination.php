<?php

return [
    'previous' => '&lsaquo; Sebelumnya',
    'next'     => 'Berikutnya &rsaquo;'
];
