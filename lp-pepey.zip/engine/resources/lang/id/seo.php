<?php

return [
    'home_title'       => 'Streaming Film & Acara TV Gratis',
    'home_description' => 'Jelajahi dan Tonton semua film & seri online favorit Anda secara gratis!',

    'movie_title' => 'Nonton :title Full Movie FIlm Online Free Gratis',
    'tv_title'    => 'Nonton :title HD Free Acara TV Gratis',
];
